// Select color input
const getColor = document.querySelector('#colorPicker');

// Select size input
const getHeight =  document.querySelector('#inputHeight');

const getWidth = document.querySelector('#inputWidth');

// When size is submitted by the user, call makeGrid()
const setGrid = document.querySelector('#pixelCanvas');
function makeGrid(h, w) {
    setGrid.innerHTML = "" //clear the grid
    for (var i = 0; i <= h; i++){
        let row = setGrid.insertRow(i);
        for (var j = 0; j<= w; j++){
            let col = row.insertCell(j);
            col.addEventListener('click', function (event) {//Coloring the boxes on the grid
                col.style.backgroundColor = getColor.value;                
                //console.log('box painted');
            });
            
        }
        
    }
}

const getSub = document.getElementById('sizePicker');
getSub.addEventListener('submit', function(event) {
    // Avoid the default behaviour of submit
    event.preventDefault()
    makeGrid (getHeight.value-1, getWidth.value-1);
});
